<?php
    define("DB_HOST", "303.itpwebdev.com");
    define("DB_USER", "yjkim_db_user");
    define("DB_PASS", "Squidward123");
    define("DB_NAME", "yjkim_fp")
?>

