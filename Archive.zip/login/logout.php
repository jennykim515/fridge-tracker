<?php
    require "../config/start.php";
    session_destroy();
    echo '<meta http-equiv="refresh" content="0; URL=login.php" />';
?>
